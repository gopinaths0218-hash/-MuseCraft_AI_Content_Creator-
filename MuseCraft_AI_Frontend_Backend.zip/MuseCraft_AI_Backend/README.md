# MuseCraft AI — Frontend + Backend

This project packages your existing MuseCraft AI HTML frontend with a Flask backend.

## Features
- `/` serves the website.
- `POST /api/generate` accepts story or social content inputs and returns generated text.
- `GET /api/health` checks that the server is running.
- If an OpenAI-compatible API key is configured, the backend requests AI-generated content.
- Without a key, it uses a local creative fallback. This fallback is template-based, not a real AI model.

## Run on Linux / Windows
1. Extract this ZIP and open the folder in VS Code.
2. Open a terminal in this folder.
3. Create and activate a virtual environment (optional but recommended):
   - Linux: `python3 -m venv .venv && source .venv/bin/activate`
   - Windows: `py -m venv .venv` then `.venv\\Scripts\\activate`
4. Install dependencies: `pip install -r requirements.txt`
5. Start server: `python app.py`
6. Open **http://127.0.0.1:5000** in Chrome.

## Enable AI generation
Set `OPENAI_API_KEY` in your terminal environment before starting the server. Optional settings:
- `OPENAI_BASE_URL` (defaults to OpenAI API base)
- `OPENAI_MODEL` (defaults to `gpt-4o-mini`)

Keep your API key private. Do not place it in the HTML or commit it to GitHub.

## Important
Open the site through the Flask URL, not by double-clicking `index.html`, because browser `file://` pages cannot call the local backend correctly.
